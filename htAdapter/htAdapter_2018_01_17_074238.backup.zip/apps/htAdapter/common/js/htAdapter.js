/*
* Licensed Materials - Property of IBM
* 5725-G92 (C) Copyright IBM Corp. 2006, 2013. All Rights Reserved.
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*/

function wlCommonInit(){
}


function myfunction(x){
	var invocationData={
			adapter:'htAdapter',
			procedure:'getNews',
			parameters:[x]
	};
	 var options={
			 onSuccess:feedScs,
			 onFailure:feedFid
	 };
	WL.Client.invokeProcedure(invocationData, options);
}

function feedScs(result){
	var news=result.invocationResult.rss.item;
	alert(news.length);
	$('#newshead').val(myhead.toUppercase()+"News");
}


function feedFid(){
	alert('Unable to contact New API');
}
